"""
train_model.py
--------------
Descarga dibujos del dataset Quick, Draw! de Google, los prepara y entrena una
red neuronal que reconoce 10 objetos. Guarda el modelo en model/.

    python train_model.py

Dataset: https://github.com/googlecreativelab/quickdraw-dataset
Cada categoría es un archivo .npy con miles de dibujos de 28x28 px.
Para no bajar archivos de ~100 MB, solo se leen los primeros N dibujos de cada
uno (unos 3 MB por categoría) y se guardan en data/ para no volver a bajarlos.
"""
import json
import os
import time
import urllib.parse
import urllib.request
from pathlib import Path

import joblib
import numpy as np
from scipy.ndimage import grey_dilation
from sklearn.metrics import accuracy_score, confusion_matrix
from sklearn.model_selection import train_test_split
from sklearn.neural_network import MLPClassifier
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

from procesamiento import normalizar

BASE = Path(__file__).parent
CARPETA_DATOS = BASE / "data"
RUTA_MODELO = BASE / "model" / "modelo_pictionary.joblib"
RUTA_META = BASE / "model" / "metadata.json"
URL_BASE = os.environ.get(
    "QUICKDRAW_URL", "https://storage.googleapis.com/quickdraw_dataset/full/numpy_bitmap/"
)
N_POR_CLASE = 4000

CLASES = [
    ("sun", "sol", "☀️"),
    ("house", "casa", "🏠"),
    ("tree", "árbol", "🌳"),
    ("fish", "pez", "🐟"),
    ("cat", "gato", "🐱"),
    ("bicycle", "bicicleta", "🚲"),
    ("umbrella", "paraguas", "☂️"),
    ("coffee cup", "taza de café", "☕"),
    ("star", "estrella", "⭐"),
    ("eyeglasses", "lentes", "👓"),
]


def descargar_clase(nombre: str, n: int = N_POR_CLASE) -> np.ndarray:
    """Devuelve un arreglo (n, 784) uint8 con los primeros n dibujos de la clase."""
    CARPETA_DATOS.mkdir(exist_ok=True)
    cache = CARPETA_DATOS / f"{nombre.replace(' ', '_')}.npy"
    if cache.exists():
        datos = np.load(cache)
        if len(datos) >= n:
            return datos[:n]

    url = URL_BASE + urllib.parse.quote(nombre) + ".npy"
    print(f"  Descargando {n} dibujos de '{nombre}'...")
    with urllib.request.urlopen(url, timeout=60) as resp:
        cabecera = resp.read(10)
        if cabecera[:6] != b"\x93NUMPY":
            raise RuntimeError(f"La respuesta de {url} no es un archivo .npy")
        if cabecera[6] == 1:
            largo = int.from_bytes(cabecera[8:10], "little")
        else:                                   
            largo = int.from_bytes(cabecera[8:10] + resp.read(2), "little")
        resp.read(largo)                        
        crudo = bytearray()
        faltan = n * 784
        while faltan > 0:                       
            bloque = resp.read(min(faltan, 1 << 20))
            if not bloque:
                break
            crudo += bloque
            faltan -= len(bloque)
    datos = np.frombuffer(bytes(crudo), dtype=np.uint8)
    datos = datos[: (len(datos) // 784) * 784].reshape(-1, 784)
    np.save(cache, datos)
    return datos


def preparar(X_crudo: np.ndarray) -> np.ndarray:
    """Aplica la misma normalización que se usa en producción."""
    return np.array([normalizar(x.reshape(28, 28)).ravel() for x in X_crudo], dtype=np.float32)


def engrosar(X: np.ndarray) -> np.ndarray:
    """Aumento de datos: versión con trazo más grueso (dilatación en gris)."""
    imgs = X.reshape(-1, 28, 28)
    return np.array([grey_dilation(im, size=(2, 2)) for im in imgs]).reshape(-1, 784)


def main():
    t0 = time.time()
    print("1) Obteniendo datos")
    X, y = [], []
    for indice, (nombre, _, _) in enumerate(CLASES):
        crudo = descargar_clase(nombre)
        X.append(preparar(crudo))
        y.append(np.full(len(crudo), indice))
    X, y = np.vstack(X), np.concatenate(y)
    print(f"   {len(X)} dibujos, {len(CLASES)} clases")

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )
    X_train = np.vstack([X_train, engrosar(X_train)])
    y_train = np.concatenate([y_train, y_train])

    print("2) Entrenando red neuronal")
    modelo = Pipeline([
        ("escalador", StandardScaler()),
        ("mlp", MLPClassifier(hidden_layer_sizes=(256, 128), activation="relu",
                              alpha=1e-3, batch_size=256, max_iter=60,
                              early_stopping=True, n_iter_no_change=5,
                              random_state=42, verbose=False)),
    ])
    modelo.fit(X_train, y_train)

    y_pred = modelo.predict(X_test)
    acc = accuracy_score(y_test, y_pred)
    print(f"3) Exactitud en prueba: {acc:.3f}")

    cm = confusion_matrix(y_test, y_pred)
    np.fill_diagonal(cm, 0)
    pares = sorted(((cm[i, j], i, j) for i in range(len(CLASES)) for j in range(len(CLASES))), reverse=True)[:3]
    for cuenta, i, j in pares:
        if cuenta:
            print(f"   confunde {CLASES[i][1]} con {CLASES[j][1]}: {cuenta} veces")

    RUTA_MODELO.parent.mkdir(exist_ok=True)
    joblib.dump(modelo, RUTA_MODELO)
    metadata = {
        "nombre": "Pictionary con IA",
        "algoritmo": "Red neuronal MLP (256-128, ReLU) + StandardScaler",
        "dataset": "Google Quick, Draw! (28x28 px)",
        "muestras_entrenamiento": int(len(X_train)),
        "muestras_prueba": int(len(X_test)),
        "exactitud_prueba": round(float(acc), 4),
        "clases": [{"id": i, "nombre": n, "etiqueta": e, "emoji": em}
                   for i, (n, e, em) in enumerate(CLASES)],
    }
    RUTA_META.write_text(json.dumps(metadata, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"Listo en {time.time() - t0:.0f} s. Modelo guardado en {RUTA_MODELO}")


if __name__ == "__main__":
    main()
