"""
app.py  —  Backend (solo Flask)
-------------------------------
Despliega el modelo "Pictionary con IA" como servicio web.

Rutas:
    GET  /             -> página del juego (templates/index.html)
    GET  /api/info     -> JSON con datos del modelo y las clases que reconoce
    POST /api/predict  -> recibe los trazos del dibujo y devuelve el top 3 en JSON

Ejecutar:
    python app.py          y abrir  http://127.0.0.1:5000
"""
import json
import time
from pathlib import Path

import joblib
from flask import Flask, jsonify, render_template, request

from procesamiento import renderizar_trazos

BASE = Path(__file__).parent
RUTA_MODELO = BASE / "model" / "modelo_pictionary.joblib"
RUTA_META = BASE / "model" / "metadata.json"

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 1 * 1024 * 1024   

if not RUTA_MODELO.exists():
    print("No se encontró el modelo; descargando datos (~30 MB) y entrenando (unos minutos)...")
    import train_model
    train_model.main()

modelo = joblib.load(RUTA_MODELO)
metadata = json.loads(RUTA_META.read_text(encoding="utf-8"))
CLASES = metadata["clases"]
estadisticas = {"predicciones": 0}


@app.route("/")
def index():
    return render_template("index.html", titulo=metadata["nombre"])


@app.route("/api/info", methods=["GET"])
def info():
    return jsonify({**metadata, "predicciones_realizadas": estadisticas["predicciones"]})


@app.route("/api/predict", methods=["POST"])
def predict():
    """
    Espera JSON:  {"trazos": [ [[x, y], [x, y], ...], [[x, y], ...], ... ]}
    Cada trazo es la lista de puntos entre que se presiona y se suelta el mouse.
    """
    t0 = time.perf_counter()
    datos = request.get_json(silent=True)
    if not datos or "trazos" not in datos:
        return jsonify({"error": "Se esperaba un JSON con el campo 'trazos'."}), 400

    try:
        imagen = renderizar_trazos(datos["trazos"])         
        probabilidades = modelo.predict_proba(imagen.reshape(1, -1))[0]
    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    except Exception as e:
        return jsonify({"error": f"Error al procesar el dibujo: {e}"}), 500

    orden = probabilidades.argsort()[::-1]                  
    top3 = [{**CLASES[i], "probabilidad": round(float(probabilidades[i]), 4)} for i in orden[:3]]

    estadisticas["predicciones"] += 1
    return jsonify({
        "top3": top3,
        "probabilidades": [round(float(p), 4) for p in probabilidades],
        "imagen_28x28": imagen.round(2).tolist(),            # lo que "ve" el modelo
        "tiempo_ms": round((time.perf_counter() - t0) * 1000, 1),
    })


@app.errorhandler(404)
def no_encontrado(_):
    return jsonify({"error": "Ruta no encontrada."}), 404


@app.errorhandler(413)
def muy_grande(_):
    return jsonify({"error": "La petición es demasiado grande."}), 413


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=True)
