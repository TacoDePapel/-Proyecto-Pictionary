"""
procesamiento.py
----------------
Convierte los dibujos al formato que entiende el modelo: una imagen de 28x28 px
con valores entre 0 y 1 (1 = tinta), centrada y escalada.

La MISMA función `normalizar` se usa en el entrenamiento (train_model.py) y en
producción (app.py). Así se evita el error clásico de preparar los datos de una
forma al entrenar y de otra al predecir.

Dos entradas posibles:
  - Entrenamiento: bitmaps de 28x28 del dataset Quick, Draw! de Google.
  - Producción:    los trazos que manda el navegador, como listas de puntos
                   [[x, y], [x, y], ...]. Se dibujan aquí con Pillow.
"""
import numpy as np
from PIL import Image, ImageDraw

TAM = 28            # tamaño final (igual que el dataset)
CAJA = 22           # el dibujo se escala para que su lado mayor mida 22 px
ESCALA_RENDER = 10  # los trazos se dibujan a 280x280 y luego se reducen (suavizado)
GROSOR = 26         # grosor de línea a 280 px  ->  ~2.5 px a 28 px, como Quick Draw
MAX_PUNTOS = 5000   # protección contra peticiones gigantes


def normalizar(img: np.ndarray) -> np.ndarray:
    """Recibe una imagen 28x28 (tinta = valores altos) y devuelve el dibujo
    recortado, escalado a CAJA px por su lado mayor, centrado y en rango 0-1."""
    img = np.asarray(img, dtype=np.float32).reshape(TAM, TAM)
    if img.mean() > 127:            # fondo claro con tinta oscura -> invertir
        img = 255 - img
    maximo = img.max()
    if maximo <= 0:
        raise ValueError("El dibujo está vacío.")

    mascara = img > maximo * 0.1
    filas = np.where(mascara.any(axis=1))[0]
    cols = np.where(mascara.any(axis=0))[0]
    recorte = img[filas[0]:filas[-1] + 1, cols[0]:cols[-1] + 1]

    h, w = recorte.shape
    factor = CAJA / max(h, w)
    nh, nw = max(1, round(h * factor)), max(1, round(w * factor))
    reducido = Image.fromarray((recorte / maximo * 255).astype(np.uint8)).resize((nw, nh), Image.BILINEAR)

    lienzo = np.zeros((TAM, TAM), dtype=np.float32)
    y0, x0 = (TAM - nh) // 2, (TAM - nw) // 2
    lienzo[y0:y0 + nh, x0:x0 + nw] = np.asarray(reducido, dtype=np.float32)

    # 4. Rango 0-1
    return lienzo / max(lienzo.max(), 1e-6)


def renderizar_trazos(trazos) -> np.ndarray:
    """Dibuja los trazos (coordenadas del canvas) en una imagen 28x28.
    El tamaño del dibujo se normaliza ANTES de dibujar, así el grosor del trazo
    es el mismo sin importar si el usuario dibujó grande o pequeño."""
    if not isinstance(trazos, list) or not trazos:
        raise ValueError("No se recibieron trazos.")
    puntos = [p for t in trazos for p in t]
    if len(puntos) > MAX_PUNTOS:
        raise ValueError("El dibujo tiene demasiados puntos.")
    try:
        xy = np.array(puntos, dtype=np.float32).reshape(-1, 2)
    except (ValueError, TypeError):
        raise ValueError("Formato de trazos inválido: se esperaba [[x, y], ...].")

    minimo, maximo = xy.min(axis=0), xy.max(axis=0)
    lado = max((maximo - minimo).max(), 1.0)
    lienzo_px = TAM * ESCALA_RENDER
    factor = (CAJA * ESCALA_RENDER) / lado
    centro = (minimo + maximo) / 2

    def transformar(p):
        return tuple((np.asarray(p, dtype=np.float32) - centro) * factor + lienzo_px / 2)

    img = Image.new("L", (lienzo_px, lienzo_px), 0)
    dib = ImageDraw.Draw(img)
    r = GROSOR / 2
    for trazo in trazos:
        pts = [transformar(p) for p in trazo]
        if len(pts) > 1:
            dib.line(pts, fill=255, width=GROSOR, joint="curve")
        for x, y in (pts[0], pts[-1]):                 
            dib.ellipse([x - r, y - r, x + r, y + r], fill=255)

    pequeña = np.asarray(img.resize((TAM, TAM), Image.BOX), dtype=np.float32)
    return normalizar(pequeña)
