# 🎨 Pictionary con IA — Despliegue de un modelo con Flask

Proyecto de **Herramientas de Desarrollo para Inteligencia Artificial**.

Tú dibujas y una red neuronal adivina qué es, en tiempo real, como el *Quick, Draw!* de Google. El juego tiene 6 rondas de 20 segundos, puntos por rapidez y voz. El proyecto muestra el ciclo completo de una aplicación de IA: **datos → entrenamiento → modelo guardado → API en Flask → frontend con jQuery**.

---

## 0. Herramientas utilizadas

| Herramienta | Tipo | Para qué se usa |
|---|---|---|
| **Python** | Lenguaje | Backend, entrenamiento y procesamiento |
| **venv** | Entorno virtual | Aislar las dependencias del proyecto |
| **pip** + `requirements.txt` | Gestor de paquetes | Instalar las librerías |
| **Git** + `.gitignore` | Control de versiones | Versionar el código sin subir datos ni modelos |
| **scikit-learn** | Machine learning | `Pipeline`, `StandardScaler`, `MLPClassifier`, métricas |
| **NumPy / SciPy** | Cómputo numérico | Arreglos, `reshape`, dilatación (`scipy.ndimage`) |
| **Pillow** | Imágenes | Dibujar los trazos y redimensionar a 28×28 |
| **joblib** | Serialización | Guardar y cargar el modelo entrenado |
| **urllib** | HTTP (Python) | Descargar el dataset |
| **Flask** + **Jinja2** | Framework web / plantillas | Servidor, rutas, API JSON y HTML |
| **HTML5 / CSS3** | Frontend | `<canvas>`, diseño con Grid y variables CSS |
| **jQuery** | Librería JS | Eventos, DOM, animaciones y AJAX |
| **Web Speech API** | API del navegador | La voz de la IA |
| **CDN** | Distribución | Cargar jQuery, con copia local de respaldo |

---

## 1. Cómo ejecutarlo

```bash
python -m venv venv
venv\Scripts\activate            # Windows   (Linux/macOS: source venv/bin/activate)
pip install -r requirements.txt

python train_model.py            # descarga ~30 MB y entrena (unos minutos). Solo una vez.
python app.py                    # abrir http://127.0.0.1:5000
```

> ⚠️ **Entrena en tu casa, antes de la presentación.** La descarga necesita internet. Después, el juego funciona sin internet: los datos quedan en `data/` y el modelo en `model/`.
>
> Si la red de la escuela bloquea la descarga, baja a mano los archivos `.npy` de
> `https://storage.googleapis.com/quickdraw_dataset/full/numpy_bitmap/<nombre>.npy`
> (por ejemplo `cat.npy`, `coffee%20cup.npy`). Renómbralos con guion bajo (`coffee_cup.npy`) y ponlos en `data/`.

---

## 2. Estructura

```
pictionary_ia/
├── app.py              ← Backend Flask (rutas y API)
├── procesamiento.py    ← Trazos → imagen 28×28 (la MISMA función al entrenar y al predecir)
├── train_model.py      ← Descarga datos, entrena y guarda el modelo
├── requirements.txt
├── .gitignore
├── data/               ← dibujos descargados (se genera)
├── model/              ← modelo .joblib + metadata.json (se genera)
├── templates/index.html
└── static/
    ├── css/styles.css
    └── js/main.js  (+ vendor/jquery-3.6.1.min.js)
```

---

## 3. Cómo se conectan frontend y backend

```
 NAVEGADOR (HTML + CSS + jQuery)                         SERVIDOR (Flask)
 ───────────────────────────────                         ─────────────────────────────
 GET /  ──────────────────────────────────────────────▶ render_template("index.html")
 $.getJSON("/api/info") ──────────────────────────────▶ jsonify(metadata)  → clases, exactitud
 
 El usuario dibuja. Cada trazo se guarda como puntos:
   trazos = [ [[120,80],[125,84],...], [[200,90],...] ]
 Al soltar el mouse (y cada 700 ms mientras dibuja):
 $.ajax POST /api/predict  {"trazos": [...]} ─────────▶ request.get_json()
                                                         ↓ renderizar_trazos() → imagen 28×28
                                                         ↓ modelo.predict_proba()
              ◀──────── {"top3": [{"etiqueta": "gato", "emoji": "🐱", "probabilidad": 0.91}, ...],
                         "imagen_28x28": [...], "tiempo_ms": 2.1}
 jQuery actualiza el top 3, el globo de texto, la vista 28×28,
 y si acierta el objeto pedido: suma puntos, habla y pasa a la siguiente ronda.
```

### API

| Método | Ruta | Entrada | Respuesta |
|---|---|---|---|
| GET | `/` | — | Página HTML |
| GET | `/api/info` | — | JSON: algoritmo, exactitud, clases |
| POST | `/api/predict` | JSON `{"trazos": [[[x,y],...],...]}` | JSON: `top3`, `probabilidades`, `imagen_28x28`, `tiempo_ms` |

Errores: `400` (sin trazos o formato inválido), `404`, `413` (petición > 1 MB), `500`. Todos regresan `{"error": "..."}`.

Probar sin navegador:
```bash
curl -X POST http://127.0.0.1:5000/api/predict -H "Content-Type: application/json" -d "{\"trazos\": [[[50,50],[150,50],[150,150],[50,150],[50,50]]]}"
```

---

## 4. Procesamiento: por qué se mandan trazos y no una imagen

El dataset de Google guarda los dibujos como **trazos** (vectores) y después los convierte a imágenes de 28×28. Este proyecto hace lo mismo:

1. El navegador manda las coordenadas de cada trazo (es más ligero que una imagen).
2. Flask calcula el rectángulo del dibujo y lo **escala antes de dibujarlo**. Así el grosor de la línea es igual aunque dibujes grande o pequeño.
3. Lo dibuja con Pillow a 280×280 y lo reduce a 28×28 (los bordes quedan suaves).
4. `normalizar()` recorta, centra y deja los valores entre 0 y 1.

👉 **Idea clave:** `normalizar()` se usa **igual** en `train_model.py` y en `app.py`. Si los datos se preparan distinto al entrenar y al predecir (*training-serving skew*), el modelo falla en producción aunque haya salido muy bien en las pruebas.

---

## 5. El modelo

- **Datos:** 10 categorías de Quick, Draw!, 4,000 dibujos de cada una (40,000 en total)
- **Descarga eficiente:** de cada `.npy` (~100 MB) se leen solo los primeros 4,000 dibujos: el script lee el encabezado del archivo y corta la descarga
- **División:** 80 % entrenamiento / 20 % prueba, estratificada
- **Aumento de datos:** se agrega una copia de cada dibujo con trazo más grueso (dilatación)
- **Pipeline:** `StandardScaler` → `MLPClassifier(256, 128, ReLU)` con *early stopping*
- **Salida:** `predict_proba` → probabilidad de cada clase → top 3
- **Guardado:** `joblib.dump()`; Flask lo carga **una vez** al iniciar

Clases: ☀️ sol · 🏠 casa · 🌳 árbol · 🐟 pez · 🐱 gato · 🚲 bicicleta · ☂️ paraguas · ☕ taza de café · ⭐ estrella · 👓 lentes

---

## 6. Tips para la presentación (por el punto extra)

- **Abre con la demo, no con el código.** Pide al profesor o a un compañero que juegue una ronda.
- Muestra el panel **"Lo que veo (28×28)"**: explica que la IA ve tu dibujo así de pequeño.
- Menciona el guiño local: ☕ taza de café y ☂️ paraguas, para Xalapa.
- Explica tres decisiones técnicas: (1) mandar trazos en vez de imagen, (2) usar la misma normalización al entrenar y al predecir, (3) descargar solo una parte del dataset.
- Cierra con el diagrama de la sección 3.

---

## 7. Conceptos clave

**Flask:** `Flask(__name__)`, `@app.route(..., methods=[...])`, `render_template`, `request.get_json()`, `jsonify`, `@app.errorhandler`, `MAX_CONTENT_LENGTH`, `debug=True` (solo en desarrollo), carpetas `templates/` y `static/`, `url_for`.

**jQuery:** `$(function(){})`, selectores, `.on()` para eventos de mouse y touch, `$.ajax` con `.done/.fail/.always`, `$.getJSON`, `contentType: "application/json"` + `JSON.stringify`, `.text/.html/.css/.addClass/.toggleClass`, `.animate/.fadeIn`, `$.each`, `$.extend`.

**Web:** AJAX, JSON, GET vs POST, códigos HTTP, CDN, *throttling* (limitar la frecuencia de peticiones), Canvas API, Web Speech API.

---

## 8. Posibles preguntas del examen (con respuesta)

**Flask y backend**
1. **¿Qué hace `jsonify()`?** Convierte un diccionario en una respuesta HTTP con JSON y `Content-Type: application/json`.
2. **¿Dónde busca Flask las plantillas y los estáticos?** En `templates/` y `static/`.
3. **¿Qué es Jinja2?** El motor de plantillas de Flask: inserta variables en el HTML con `{{ titulo }}`.
4. **¿Para qué sirve `url_for('static', filename=...)`?** Genera la URL correcta de un archivo estático.
5. **¿Por qué el modelo se carga fuera de las funciones?** Para cargarlo una sola vez al iniciar y no en cada petición, lo que sería muy lento.
6. **¿Qué devuelve la API si llegan trazos inválidos?** Un código `400` con `{"error": "..."}`.
7. **¿Para qué sirve `MAX_CONTENT_LENGTH`?** Limita el tamaño de las peticiones; si se excede, Flask responde `413`.
8. **¿Por qué no usar `debug=True` en producción?** Expone un depurador que permite ejecutar código en el servidor.
9. **¿Qué se usa en producción en lugar de `app.run()`?** Un servidor WSGI como Gunicorn o Waitress, normalmente detrás de Nginx.

**Frontend y jQuery**
10. **¿Qué es AJAX?** Peticiones al servidor en segundo plano, sin recargar la página.
11. **¿Cómo se envían los trazos?** Con `$.ajax` por POST, `contentType: "application/json"` y `data: JSON.stringify({trazos})`.
12. **¿Qué hacen `.done()`, `.fail()` y `.always()`?** Se ejecutan si la petición sale bien, si falla, y en ambos casos.
13. **¿Por qué se limita a una petición cada 700 ms al dibujar?** Es *throttling*: evita saturar el servidor con cientos de peticiones por segundo.
14. **¿Para qué la copia local de jQuery?** Si el CDN no carga, `window.jQuery` es `undefined` y se carga la copia de `/static`.
15. **¿Qué diferencia hay entre jQuery y Node.js?** jQuery es una librería que corre en el **navegador**; Node.js es un **entorno** para ejecutar JavaScript fuera del navegador (servidores y herramientas como npm).
16. **¿Cómo habla la IA?** Con la Web Speech API del navegador (`speechSynthesis`), sin servidor extra.

**Modelo y datos**
17. **¿Qué dataset se usó?** Google Quick, Draw!: millones de dibujos en 345 categorías; se usaron 10.
18. **¿Por qué mandar trazos y no una imagen?** Es más ligero, imita cómo se generó el dataset y permite normalizar el tamaño antes de dibujar.
19. **¿Qué es el *training-serving skew*?** Preparar los datos distinto al entrenar y al predecir. Se evita usando la misma función `normalizar()` en los dos lugares.
20. **¿Qué hace `StandardScaler`?** Deja cada característica con media 0 y desviación estándar 1; ayuda a que la red converja.
21. **¿Qué devuelve `predict_proba`?** Una probabilidad por clase (suman 1); de ahí sale el top 3.
22. **¿Qué es *early stopping*?** Detener el entrenamiento cuando el error en un conjunto de validación deja de mejorar; evita el sobreajuste.
23. **¿Qué es el aumento de datos y cuál se usó?** Crear muestras nuevas transformando las existentes; aquí se agregó una versión con trazo más grueso.
24. **¿Por qué estratificar la división?** Para que entrenamiento y prueba tengan la misma proporción de cada clase.

**Herramientas de desarrollo**
25. **¿Para qué sirve `venv`?** Aísla las librerías de cada proyecto para que sus versiones no choquen.
26. **¿Qué es `requirements.txt`?** La lista de dependencias. Se instala con `pip install -r requirements.txt` y se genera con `pip freeze > requirements.txt`.
27. **¿Por qué `data/` y el modelo están en `.gitignore`?** Son archivos grandes que se pueden regenerar; en Git se versiona el código, no los datos.
28. **¿Para qué `joblib`? ¿Qué riesgo tiene?** Guarda el modelo entrenado para no re-entrenarlo. Un archivo de `joblib` o `pickle` puede ejecutar código al cargarse, así que solo deben cargarse modelos confiables.
29. **¿Qué ventaja tiene el `Pipeline` de scikit-learn?** Une el preprocesamiento y el modelo en un solo objeto que se entrena, guarda y usa junto.
30. **¿Cómo se descargó solo una parte de cada archivo?** El formato `.npy` tiene un encabezado y luego los datos seguidos: se lee el encabezado, se leen los bytes de 4,000 dibujos (4,000 × 784) y se cierra la conexión.

---

## 9. Limitaciones y mejoras

- Una **red MLP** trata la imagen como 784 números sueltos. Una **CNN** (redes convolucionales, con Keras o PyTorch) aprovecha la forma de la imagen y sería más precisa.
- Más clases o más dibujos por clase mejoran el modelo, pero tardan más en entrenar.
- Despliegue real: Gunicorn + Nginx, o servicios como Render o Railway.
