/*
 * main.js — Frontend del "Pictionary con IA" (jQuery)
 * ----------------------------------------------------
 * 1. Captura los trazos del canvas como listas de puntos [[x, y], ...]
 * 2. Los envía a Flask con $.ajax (JSON) mientras dibujas
 * 3. Muestra el top 3 que regresa el modelo
 * 4. Lógica del juego: rondas, temporizador, puntos y voz
 */
$(function () {

    // ==================================================================
    // Estado global
    // ==================================================================
    const RONDAS = 6;
    const SEGUNDOS = 20;
    const ARTICULOS = {                     // para que la voz hable bonito
        "sun": "un", "house": "una", "tree": "un", "fish": "un", "cat": "un",
        "bicycle": "una", "umbrella": "un", "coffee cup": "una", "star": "una", "eyeglasses": "unos"
    };

    let clases = [];                // llegan de /api/info
    let trazos = [];                // [[ [x,y], [x,y] ], ...]
    let trazoActual = null;
    let dibujando = false;
    let bloqueado = false;          // evita dibujar entre rondas

    let peticionEnCurso = false;
    let repetirPeticion = false;
    let ultimaPeticion = 0;

    let vozActiva = true;
    let ultimaFrase = "";
    let ultimoHabla = 0;

    const juego = { activo: false, ronda: 0, puntos: 0, lista: [], objetivo: null,
                    fin: 0, intervalo: null, resuelto: false, aciertos: 0 };

    // ==================================================================
    // Canvas
    // ==================================================================
    const $lienzo = $("#lienzo");
    const canvas = $lienzo[0];
    const ctx = canvas.getContext("2d");

    function limpiarLienzo() {
        ctx.fillStyle = "#ffffff";
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        trazos = [];
        trazoActual = null;
    }
    limpiarLienzo();

    function posicion(e) {
        const r = canvas.getBoundingClientRect();
        const ev = e.originalEvent.touches ? e.originalEvent.touches[0] : e;
        return [
            Math.round((ev.clientX - r.left) * canvas.width / r.width),
            Math.round((ev.clientY - r.top) * canvas.height / r.height)
        ];
    }

    $lienzo.on("mousedown touchstart", function (e) {
        e.preventDefault();
        if (bloqueado) return;
        dibujando = true;
        const p = posicion(e);
        trazoActual = [p];
        trazos.push(trazoActual);
        ctx.beginPath();
        ctx.moveTo(p[0], p[1]);
        ctx.lineWidth = 9;
        ctx.lineCap = "round";
        ctx.lineJoin = "round";
        ctx.strokeStyle = "#1d1b2e";
        ctx.lineTo(p[0] + 0.1, p[1]);      // un clic deja un punto visible
        ctx.stroke();
    });

    $lienzo.on("mousemove touchmove", function (e) {
        if (!dibujando) return;
        e.preventDefault();
        const p = posicion(e);
        const ultimo = trazoActual[trazoActual.length - 1];
        if (Math.hypot(p[0] - ultimo[0], p[1] - ultimo[1]) < 2) return;   // ignora micro-movimientos
        trazoActual.push(p);
        ctx.lineTo(p[0], p[1]);
        ctx.stroke();
        // Predicción "en vivo" mientras dibujas (máximo una cada 700 ms)
        if (Date.now() - ultimaPeticion > 700) predecir();
    });

    $(document).on("mouseup touchend", function () {
        if (!dibujando) return;
        dibujando = false;
        predecir();                         // siempre predecir al terminar un trazo
    });

    $("#btn-limpiar").on("click", function () {
        limpiarLienzo();
        decir("Lienzo limpio. ¡Dibuja otra vez!", false);
        $("#top3").html('<li class="vacio">Esperando un dibujo…</li>');
    });

    // ==================================================================
    // AJAX: enviar trazos a Flask  ->  POST /api/predict
    // ==================================================================
    function predecir() {
        if (!trazos.length) return;
        if (peticionEnCurso) { repetirPeticion = true; return; }
        peticionEnCurso = true;
        ultimaPeticion = Date.now();

        $.ajax({
            url: "/api/predict",
            method: "POST",
            contentType: "application/json",
            data: JSON.stringify({ trazos: trazos }),
            dataType: "json"
        })
            .done(mostrarPrediccion)
            .fail(function (xhr) {
                const msg = (xhr.responseJSON && xhr.responseJSON.error) || "No pude contactar al servidor.";
                decir("⚠️ " + msg, false);
            })
            .always(function () {
                peticionEnCurso = false;
                if (repetirPeticion) { repetirPeticion = false; predecir(); }
            });
    }

    // ==================================================================
    // Mostrar la respuesta
    // ==================================================================
    function mostrarPrediccion(r) {
        if (!trazos.length) return;         // llegó tarde y el lienzo ya se limpió
        if (juego.activo && juego.resuelto) return;   // la ronda ya terminó

        // --- Top 3 ---
        const $lista = $("#top3").empty();
        $.each(r.top3, function (i, c) {
            const pct = Math.round(c.probabilidad * 100);
            const $barra = $("<div>").addClass("relleno");
            $("<li>").toggleClass("primera", i === 0)
                .append($("<span>").addClass("emoji").text(c.emoji))
                .append($("<span>").addClass("nombre").text(c.etiqueta))
                .append($("<div>").addClass("pista").append($barra))
                .append($("<span>").addClass("valor").text(pct + "%"))
                .appendTo($lista);
            $barra.animate({ width: pct + "%" }, 250);
        });

        dibujarVista28(r.imagen_28x28);
        $("#tiempo").text("Respuesta del servidor en " + r.tiempo_ms + " ms");

        // --- ¿Qué dice la IA? ---
        const mejor = r.top3[0];
        const segunda = r.top3[1];
        if (juego.activo && !juego.resuelto) {
            if (mejor.nombre === juego.objetivo.nombre && mejor.probabilidad >= 0.5) {
                acierto();
                return;
            }
        }
        $("#avatar").text("🤔");
        if (mejor.probabilidad >= 0.6) {
            decir("Creo que es " + articulo(mejor) + " " + mejor.etiqueta + "…", true);
        } else {
            decir("Mmm… ¿" + mejor.etiqueta + "? ¿o " + segunda.etiqueta + "?", false);
        }
    }

    function articulo(c) { return ARTICULOS[c.nombre] || ""; }

    // Pinta la matriz 28x28 en un canvas diminuto (se agranda con CSS)
    function dibujarVista28(matriz) {
        const c = $("#vista28")[0].getContext("2d");
        const img = c.createImageData(28, 28);
        for (let y = 0; y < 28; y++) {
            for (let x = 0; x < 28; x++) {
                const v = 255 - Math.round(matriz[y][x] * 255);
                const i = (y * 28 + x) * 4;
                img.data[i] = img.data[i + 1] = img.data[i + 2] = v;
                img.data[i + 3] = 255;
            }
        }
        c.putImageData(img, 0, 0);
    }

    // ==================================================================
    // Voz (Web Speech API del navegador)
    // ==================================================================
    function decir(texto, hablar) {
        $("#globo").text(texto);
        if (!hablar || !vozActiva || !("speechSynthesis" in window)) return;
        if (texto === ultimaFrase || Date.now() - ultimoHabla < 2500) return;   // no ser repetitivo
        ultimaFrase = texto;
        ultimoHabla = Date.now();
        hablarYa(texto);
    }

    function hablarYa(texto) {
        if (!vozActiva || !("speechSynthesis" in window)) return;
        window.speechSynthesis.cancel();
        const u = new SpeechSynthesisUtterance(texto.replace(/[…¿?¡!]/g, " "));
        const voces = window.speechSynthesis.getVoices();
        u.voice = voces.find(v => v.lang === "es-MX") || voces.find(v => v.lang.startsWith("es")) || null;
        u.lang = "es-MX";
        u.rate = 1.05;
        window.speechSynthesis.speak(u);
    }

    $("#btn-voz").on("click", function () {
        vozActiva = !vozActiva;
        $(this).text(vozActiva ? "🔊 Voz" : "🔇 Voz").toggleClass("apagado", !vozActiva);
        if (!vozActiva && "speechSynthesis" in window) window.speechSynthesis.cancel();
    });

    // ==================================================================
    // Lógica del juego
    // ==================================================================
    function barajar(arr) {
        const a = arr.slice();
        for (let i = a.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [a[i], a[j]] = [a[j], a[i]];
        }
        return a;
    }

    function empezarJuego() {
        if (!clases.length) return;
        $.extend(juego, { activo: true, ronda: 0, puntos: 0, aciertos: 0, lista: barajar(clases).slice(0, RONDAS) });
        $("#puntos").text(0);
        $("#historial").empty();
        $("#btn-jugar").text("↺ Reiniciar");
        $("#btn-saltar").prop("disabled", false);
        $("#modal-final").addClass("oculto");
        siguienteRonda();
    }

    function siguienteRonda() {
        clearInterval(juego.intervalo);
        juego.ronda++;
        if (juego.ronda > RONDAS) { terminarJuego(); return; }

        juego.objetivo = juego.lista[juego.ronda - 1];
        juego.resuelto = false;
        bloqueado = false;
        limpiarLienzo();
        $("#top3").html('<li class="vacio">Esperando un dibujo…</li>');
        $("#ronda").text(juego.ronda + " / " + RONDAS);
        $("#avatar").text("🤖");
        $("#reto").html(
            '<span class="reto-texto">Dibuja:</span> ' +
            '<span class="reto-emoji">' + juego.objetivo.emoji + '</span> ' +
            '<strong>' + juego.objetivo.etiqueta + '</strong>'
        ).hide().fadeIn(250);
        decir("¡A ver! Dibuja " + articulo(juego.objetivo) + " " + juego.objetivo.etiqueta + ".", false);
        hablarYa("Dibuja " + articulo(juego.objetivo) + " " + juego.objetivo.etiqueta);

        juego.fin = Date.now() + SEGUNDOS * 1000;
        juego.intervalo = setInterval(actualizarTiempo, 100);
        actualizarTiempo();
    }

    function actualizarTiempo() {
        const restante = Math.max(0, juego.fin - Date.now());
        const pct = restante / (SEGUNDOS * 1000) * 100;
        $("#barra-tiempo").css("width", pct + "%").toggleClass("urgente", pct < 25);
        if (restante <= 0) terminarRonda(false, "¡Se acabó el tiempo!");
    }

    function acierto() {
        const segundos = Math.ceil((juego.fin - Date.now()) / 1000);
        const ganados = 50 + segundos * 10;              // más rápido = más puntos
        juego.puntos += ganados;
        juego.aciertos++;
        $("#puntos").text(juego.puntos);
        $("#avatar").text("🤩");
        decir("¡Ya sé! ¡Es " + articulo(juego.objetivo) + " " + juego.objetivo.etiqueta + "! (+" + ganados + ")", false);
        hablarYa("¡Ya sé! Es " + articulo(juego.objetivo) + " " + juego.objetivo.etiqueta);
        terminarRonda(true);
    }

    function terminarRonda(gano, motivo) {
        if (juego.resuelto) return;
        juego.resuelto = true;
        bloqueado = true;
        dibujando = false;
        clearInterval(juego.intervalo);

        if (!gano) {
            $("#avatar").text("😅");
            const texto = motivo + " No adiviné " + articulo(juego.objetivo) + " " + juego.objetivo.etiqueta + ".";
            decir(texto, false);
            hablarYa(texto);
        }
        agregarHistorial(gano);
        $.getJSON("/api/info").done(pintarInfo);          // refresca el contador
        setTimeout(siguienteRonda, 2000);
    }

    function agregarHistorial(gano) {
        $("#historial .vacio").remove();
        $("<li>").addClass(gano ? "gano" : "perdio")
            .append($("<img>").attr("src", canvas.toDataURL("image/png")))
            .append($("<span>").text(juego.objetivo.emoji + " " + (gano ? "✓" : "✗")))
            .hide().appendTo("#historial").fadeIn(200);
    }

    function terminarJuego() {
        juego.activo = false;
        bloqueado = false;
        clearInterval(juego.intervalo);
        $("#btn-jugar").text("▶ Empezar juego");
        $("#btn-saltar").prop("disabled", true);
        $("#ronda").text("–");
        $("#reto").html('<span class="reto-texto">Modo libre: dibuja lo que quieras</span>');
        $("#barra-tiempo").css("width", "100%").removeClass("urgente");

        const ratio = juego.aciertos / RONDAS;
        $("#final-emoji").text(ratio >= 0.8 ? "🏆" : ratio >= 0.5 ? "🎉" : "🖍️");
        $("#final-titulo").text(ratio >= 0.8 ? "¡Somos un gran equipo!" : ratio >= 0.5 ? "¡Bien jugado!" : "¡A practicar!");
        $("#final-texto").text("Adiviné " + juego.aciertos + " de " + RONDAS + " dibujos · " + juego.puntos + " puntos");
        $("#modal-final").removeClass("oculto").hide().fadeIn(200);
        hablarYa("Adiviné " + juego.aciertos + " de " + RONDAS + " dibujos");
    }

    $("#btn-jugar, #btn-otra").on("click", empezarJuego);
    $("#btn-saltar").on("click", function () {
        if (juego.activo && !juego.resuelto) terminarRonda(false, "Ronda saltada.");
    });

    // ==================================================================
    // GET /api/info  al cargar la página
    // ==================================================================
    function pintarInfo(info) {
        $("#estado-servidor").addClass("ok").removeClass("caido").find(".texto").text("Servidor en línea");
        clases = info.clases;
        const $chips = $("#clases").empty();
        $.each(clases, function (_, c) {
            $("<span>").addClass("chip").text(c.emoji + " " + c.etiqueta).appendTo($chips);
        });
        const filas = {
            "Algoritmo": info.algoritmo,
            "Dataset": info.dataset,
            "Dibujos de entrenamiento": info.muestras_entrenamiento.toLocaleString("es-MX"),
            "Exactitud en prueba": (info.exactitud_prueba * 100).toFixed(1) + " %",
            "Predicciones atendidas": info.predicciones_realizadas
        };
        const $dl = $("#info-modelo").empty();
        $.each(filas, function (k, v) { $dl.append($("<dt>").text(k), $("<dd>").text(v)); });
    }

    $.getJSON("/api/info")
        .done(pintarInfo)
        .fail(function () {
            $("#estado-servidor").addClass("caido").find(".texto").text("Servidor no disponible");
            $("#btn-jugar").prop("disabled", true);
        });
});
